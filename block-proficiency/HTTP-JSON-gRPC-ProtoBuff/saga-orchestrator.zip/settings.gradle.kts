rootProject.name = "saga-orchestrator"

include(
    "proto",
    "orchestrator",
    "payment-service",
    "inventory-service",
    "shipping-service"
)
