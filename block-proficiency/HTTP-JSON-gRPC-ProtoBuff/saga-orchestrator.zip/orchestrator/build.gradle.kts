dependencies {
    implementation(project(":proto"))
    implementation("io.ktor:ktor-server-core:2.3.10")
    implementation("io.ktor:ktor-server-netty:2.3.10")
    implementation("io.ktor:ktor-server-content-negotiation:2.3.10")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.10")
    implementation("io.grpc:grpc-services:1.63.0")  // for server reflection
}

application {
    mainClass.set("com.skidroad.saga.orchestrator.MainKt")
}
