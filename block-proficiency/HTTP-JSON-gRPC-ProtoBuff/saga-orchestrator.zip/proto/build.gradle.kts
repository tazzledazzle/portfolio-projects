import com.google.protobuf.gradle.*

plugins {
    id("com.google.protobuf")
}

val grpcVersion       = "1.63.0"
val grpcKotlinVersion = "1.4.1"
val protobufVersion   = "3.25.3"

dependencies {
    implementation("io.grpc:grpc-protobuf:$grpcVersion")
    implementation("io.grpc:grpc-kotlin-stub:$grpcKotlinVersion")
    implementation("com.google.protobuf:protobuf-kotlin:$protobufVersion")
    // Well-known types (Timestamp, Duration, Any) are included transitively
}

protobuf {
    protoc { artifact = "com.google.protobuf:protoc:$protobufVersion" }
    plugins {
        id("grpc") { artifact = "io.grpc:protoc-gen-grpc-java:$grpcVersion" }
        id("grpckt") { artifact = "io.grpc:protoc-gen-grpc-kotlin:$grpcKotlinVersion:jdk8@jar" }
    }
    generateProtoTasks {
        all().forEach { task ->
            task.plugins {
                id("grpc")
                id("grpckt")
            }
            task.builtins { id("kotlin") }
        }
    }
}

sourceSets {
    main {
        proto { srcDir("src/main/proto") }
    }
}
