dependencies {
    implementation(project(":proto"))
}
application { mainClass.set("com.skidroad.saga.PaymentServiceKt") }
